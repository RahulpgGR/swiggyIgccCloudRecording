<?php
ini_set('max_execution_time', 0);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$que=$_GET['q'];

// echo $que;

$OrderID=$_GET['q1'];
$Phone=$_GET['q2'];
$agentid=$_GET['agentid'];

// echo $agentid;die();

/*

agent id -1006,1036,1012,1083

*/

$startDate=$_GET['start_date'];
$endDate=$_GET['from_date'];

//echo $startDate;

//echo $endDate;
// die();

include_once 'db/db_connect.php';     
$db = new db();
$con = $db->connect();


//agentid
//processid

while(mysqli_more_results($con)) {mysqli_next_result($con);}
//$sqls="SELECT * FROM Record_Filenames WHERE (Phone = '$Phone' or OrderID = '$OrderID') AND CallType in ('$que')";
if(!empty($agentid))
{
//echo "one";

$sqls="SELECT * FROM Record_Filenames WHERE (Phone = '$Phone' or OrderID = '$OrderID' or agentform ='$agentid')  AND  call_record_date >= '$startDate'  AND  call_record_date <= '$endDate'  AND  CallType in ('$que')";

}

else 
  //if(!empty($startDate) && !empty($endDate))

{
//echo "two";

$sqls="SELECT * FROM Record_Filenames WHERE (Phone = '$Phone' or OrderID = '$OrderID') AND call_record_date >= '$startDate'  AND  call_record_date <= '$endDate'   AND    CallType in ('$que')"; 

}

// else
// {
//   echo "three";

//   $sqls="SELECT * FROM Record_Filenames WHERE (Phone = '$Phone' or OrderID = '$OrderID') or call_record_date >= '$startDate'  or  call_record_date <= '$endDate'   OR    CallType in ('$que')"; 
// }




$results=$db->select($sqls);


$i = 0;
foreach($results as $line) {
    $i++;
}

// exit();

$data1=$data=$data2=$data3='';


    //print_r($arrDate);
if($que == 'q') {
  $data .='<table class="table table table-bordered table-striped table-hover">
  <thead class="thead-dark">
      <tr><th colspan="13" style="text-align:center;" id="thead"> RECORDS DETAILS </th>
      </tr>
    <tr>
    <th>AgentId</th>
    <th>OrderID</th>
    <th>Phone</th>
    <th>call record date </th>
    <th>CallType</th>
        <th>FileName</th>
        <th>File Download</th>
    </tr>
  </thead>';

		foreach($results as $line) {

           /* $r = str_split($line['Agent_format'],1);
            $final_form = $r[1].$r[2].$r[3].$r[4];
            print_r($final_form); die();*/


             // print_r($line);
            $CallType = $line['CallType'];
            //print_r($CallType);
            if($CallType == 'q') {
                $CallType = 'Dialer';
            } else {
                
                $CallType = 'Manuval';

            }

            $FileFolderName = $line['FileFolderName'];
            $FileName = $line['FileName'];
            $Phone = $line['Phone'];
            $OrderID = $line['OrderID'];
			$UpdateDateTime = $line['call_record_date'];
			$url = $line['FileName'];
      $agent_id = $line['agentform'];
                $data .="<tr>
                <td>".$agent_id."</td>
                <td>".$OrderID."</td>
                <td>".$Phone."</td>
                <td>".$UpdateDateTime."</td>
                    <td>".$CallType."</td>
                    <td>".$FileName."</td>
                    <td><a onclick=GetAudioFile('$FileFolderName','$FileName')><i class='fa fa-download' style='font-size:24px'> </i></a></td>
                </tr>";
                $data2++;
        }
  $data .=  "</table>";
} else {
    $data .='<table class="table table table-bordered table-striped table-hover">
    <thead class="thead-dark">
        <tr><th colspan="13" style="text-align:center;" id="thead"> RECORDS DETAILS </th>
        </tr>
      <tr>
      <th>AgentId</th>
      <th>Phone</th>
      <th>call record date </th>
      <th>CallType</th>
          <th>FileName</th>
           <th>FileFolderName</th>
          <th>File Download</th>
      </tr>
    </thead>';
          foreach($results as $line) {
              //print_r($line);
              $CallType = $line['CallType'];
              if($CallType == 'q') {
                  $CallType = 'Dialer';
              } else {
                  $CallType = 'Manuval';
              }
  
              $FileFolderName = $line['FileFolderName'];
              $FileName = $line['FileName'];
              $Phone = $line['Phone'];
              
              $UpdateDateTime = $line['call_record_date'];
              $url = $line['FileName'];
              $agent_id = $line['agentform'];
                  $data .="<tr>
                   <td>".$agent_id."</td>
                  <td>".$Phone."</td>
                  <td>".$UpdateDateTime."</td>
                      <td>".$CallType."</td>
                      <td>".$FileName."</td>
                     <td>".$FileFolderName."</td>
                      <td><a onclick=GetAudioFile('$FileFolderName','$FileName')><i class='fa fa-download' style='font-size:24px'> </i></a></td>
                  </tr>";
                  $data2++;
          }
    $data .=  "</table>";
}


if($i > 0){
  echo $data;
} else {
    echo "<div style='text-align:center;'><h3 style='color:red;text-align:center;'>Records Not Found </h3></div>";
}
?>



