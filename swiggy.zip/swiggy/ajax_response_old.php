<?php
ini_set('max_execution_time', 0);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$OrderID=$_GET['q1'];
$Phone=$_GET['q2'];



include_once 'db/db_connect.php';     
$db = new db();
$con = $db->connect();


while(mysqli_more_results($con)){mysqli_next_result($con);}
$sqls="SELECT * FROM Record_Filenames WHERE Phone = '$Phone' or OrderID = '$OrderID'";
$results=$db->select($sqls);

$i = 0;
foreach($results as $line) {
    $i++;
}

// exit();

$data1=$data=$data2=$data3='';


    //print_r($arrDate);
 
  $data .='<table class="table table table-bordered table-striped table-hover">
  <thead class="thead-dark">
      <tr><th colspan="13" style="text-align:center;" id="thead"> RECORDS DETAILS </th>
      </tr>
    <tr>
    <th>OrderID</th>
    <th>Phone</th>
    <th>UpdateDateTime</th>
    <th>CallType</th>
        <th>FileName</th>
        <th>File Download</th>
    </tr>
  </thead>';
  
		foreach($results as $line) {
            //print_r($line);
            $CallType = $line['CallType'];
            if($CallType == 'q') {
                $CallType = 'Dialer';
            } else {
                $CallType = 'Manuval';
            }

            $FileFolderName = $line['FileFolderName'];
            $FileName = $line['FileName'];
            $Phone = $line['Phone'];
            $OrderID = $line['OrderID'];
            $UpdateDateTime = $line['UpdateDateTime'];
			$url = $line['FileName'];
                $data .="<tr>
                <td>".$OrderID."</td>
                <td>".$Phone."</td>
                <td>".$UpdateDateTime."</td>
                    <td>".$CallType."</td>
                    <td>".$FileName."</td>
                    <td><a href='http://14.98.23.206/staging/swiggy_Record_Details/".$FileFolderName."/".$FileName."' download><i class='fa fa-download' style='font-size:24px'> </i></a></td>
                </tr>";
                $data2++;
        }
  $data .=  "</table>";
  


if($i > 0){
  echo $data;
} else {
    echo "<div style='text-align:center;'><h3 style='color:red;text-align:center;'>Records Not Found </h3></div>";
}
?>
