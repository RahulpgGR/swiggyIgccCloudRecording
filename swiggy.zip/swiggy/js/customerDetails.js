/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


        $(function()
{
    //alert("hi");
    $("#ddTenantID").on("change",function()
    {
        ddTenantID=$(this).val();
        //alert($ddTenantID);
        $.ajax({
            url: "ajax_response.php?action=find_client_name&ddTenantID="+ddTenantID,
            dataType: "text",
            type: "post",
            contentType: false,
            processData: false,
            async: false,
            cache: false,
            success: function(response)
            {
               // alert(response);
               $("#client_name").html(response);
            }
            
            
        });
        
    })
});

        // alert("In js");
       
        
       $('#my_modal4').on('show.bs.modal', function(e) {
         //  alert("abhay");
        var lID = $(e.relatedTarget).data('lead4-id');
        var lName = $(e.relatedTarget).data('lead4-name');
        var cName = $(e.relatedTarget).data('lead4-client');
        var appro = $(e.relatedTarget).data('lead4-appro');
        var type = $(e.relatedTarget).data('lead4-type');
        var exec = $(e.relatedTarget).data('lead4-exec');
        var rdate = $(e.relatedTarget).data('lead4-rdate');
        //   alert(rdate);
        if(type == 'activity')        
         $(e.currentTarget).find('label[id="lblleadid4"]').text("Client : "+cName+" || Activity : "+lName);
        else
           $(e.currentTarget).find('label[id="lblleadid4"]').text("Client : "+cName+" || Activity : "+lName+" || Executive : "+exec);
         
        if(type =='activity' && appro == "appro")
            $(e.currentTarget).find('label[id="lblleadid4"]').text("Client : "+cName+" || Activity : "+lName+" || Approachable Leads");
       
                         if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
              //   alert("Hello Again "+processID);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("leaddetails4").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("leaddetails4").style.display = "block";
                xmlhttp.open("GET", "getLeadDetails.php?rdate="+rdate+"&appro="+appro+"&type="+type+"&q=" + lID+"", true);
                xmlhttp.send();
           
       
        });
        
   
   $('#my_modal3').on('show.bs.modal', function(e) {
         //  alert("abhay");
        var lID = $(e.relatedTarget).data('lead3-id');
        var lName = $(e.relatedTarget).data('lead3-name');
        var cName = $(e.relatedTarget).data('lead3-client');
        
         $(e.currentTarget).find('label[id="lblleadid3"]').text("Client : "+cName+" || Activity : "+lName);
       
       
                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
              //   alert("Hello Again "+processID);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("leaddetails3").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("leaddetails3").style.display = "block";
                xmlhttp.open("GET", "getAttendanceDetails.php?rdate=today&q=" + lID+"", true);
                xmlhttp.send();
           
       
        });
        
         $('#my_modal2').on('show.bs.modal', function(e) {
         //  alert("abhay");
        var lat = $(e.relatedTarget).data('lead2-lat');
        var long = $(e.relatedTarget).data('lead2-long');
        
         $(e.currentTarget).find('label[id="lblleadid2"]').text("");
       
       
                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
              //   alert("Hello Again "+processID);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("leaddetails2").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("leaddetails2").style.display = "block";
                xmlhttp.open("GET", "../map/index.php?lat="+lat+"&long=" +long+"", true);
                xmlhttp.send();
           
       
        });