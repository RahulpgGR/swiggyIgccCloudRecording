/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* ensure any open panels are closed before showing selected */
//$('#accordion').on('show.bs.collapse', function () {
//    
//    $('#accordion .in').collapse('hide');
//});

// alert("abhya");

$('#my_modal3').on('show.bs.modal', function(e) {
      //  alert("abhay");
        var l1ID = $(e.relatedTarget).data('lead1-id');
        // $(e.currentTarget).find('label[id="lblleadid1"]').text("FB Lead ID : "+l1ID);
       // alert(l1ID);
       
                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
              //   alert("Hello Again "+processID);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("leaddetails1").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("leaddetails1").style.display = "block";
                xmlhttp.open("GET", "getInteractionDetailsToday.php?type="+l1ID, true);
                xmlhttp.send();
           
       
        }); 
        

function showPaySenseDiv(val)
{
    if(val == "Not Eligible")
    {
        $("#ner").show();
        $("#nir").hide();
        $("#app").hide();
        $("#amt").hide();
        $("#nc").hide();
        $("#cbtime").hide();
    }
    else if(val == "Not Interested")
    {
        $("#ner").hide();
        $("#nir").show();
        $("#app").hide();
        $("#amt").hide();
        $("#nc").hide();
        $("#cbtime").hide();
    }
    else if(val == "Not Contacted")
    {
        $("#ner").hide();
        $("#nir").hide();
        $("#app").hide();
        $("#amt").hide();
        $("#nc").show();
        $("#cbtime").hide();
    }
    
    else if(val == "Call Back Requested")
    {
        $("#ner").hide();
        $("#nir").hide();
        $("#app").hide();
        $("#amt").hide();
        $("#nc").hide();
        $("#cbtime").show();
    }
    else
    {
        $("#ner").hide();
        $("#nir").hide();
        $("#app").show();
        $("#amt").show();
        $("#nc").hide();
    }
    
}



function showReport(str)
{
    // alert("Hello "+str);

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // alert("Hello Again "+str);

    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
        }
    }
    document.getElementById("divInfo").style.display = "block";
    document.getElementById("divInfo1").style.display = "block";
    xmlhttp.open("GET", "getDailyReport.php?q=" + str, true);
    xmlhttp.send();

}

function validateForm()
{
    if(document.getElementById("FinalDisposition").options[FinalDisposition.selectedIndex].value == "")
    {
        alert("Please Select the Call Disposition");
        document.forms["frm1"]["FinalDisposition"].focus();
        return false;
    }
}