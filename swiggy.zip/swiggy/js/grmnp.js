function validateForm()
{
    // alert("Hello");
    // alert(document.getElementById("ddCustomerIssue").options[ddCustomerIssue.selectedIndex].value);
  
    if(document.getElementById("ddPortOutReason").options[ddPortOutReason.selectedIndex].value == "")
    {
        alert("Please Select the Port Out Reason");
        document.forms["frm1"]["ddPortOutReason"].focus();
        return false;
    }
    
    if(document.getElementById("ddPortOutSubReason").options[ddPortOutSubReason.selectedIndex].value == "")
    {
        alert("Please Select the Port Out Sub Reason");
        document.forms["frm1"]["ddPortOutSubReason"].focus();
        return false;
    }
    
    if(document.getElementById("ddDisposition").options[ddDisposition.selectedIndex].value == "")
    {
        alert("Please Select the Disposition");
        document.forms["frm1"]["ddDisposition"].focus();
        return false;
    }
    
    if(document.getElementById("ddDispositionDetails").options[ddDispositionDetails.selectedIndex].value == "")
    {
        alert("Please Select the Disposition Details");
        document.forms["frm1"]["ddDispositionDetails"].focus();
        return false;
    }
    
}
		$(function(){ 
          
                $('#my_modal1').on('show.bs.modal', function(e) {
                  //   alert("abhay");
                  var ltype = $(e.relatedTarget).data('lead1-id');
                     // alert(ltype);
                   // $(e.currentTarget).find('label[id="lblleadid"]').text(ltype);

                           if (window.XMLHttpRequest)
                           {// code for IE7+, Firefox, Chrome, Opera, Safari
                               xmlhttp = new XMLHttpRequest();
                           }
                           else
                           {// code for IE6, IE5
                               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                           }
                         //   alert("Hello Again "+processID);

                           xmlhttp.onreadystatechange = function ()
                           {
                               if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                               {
                                   document.getElementById("ViewsegmentDetails").innerHTML = xmlhttp.responseText;
                               }
                           }
                           document.getElementById("ViewsegmentDetails").style.display = "block";
                           xmlhttp.open("GET", "getSegment.php?q=" + ltype, true);
                           xmlhttp.send();


                   });
                   
                   
                     $('#my_modal2').on('show.bs.modal', function(e) {
                 //   alert("abhay");
                    var ltype = $(e.relatedTarget).data('lead1-id');
                     //alert(ltype);
                          //   $(e.currentTarget).find('label[id="lblleadid"]').text(ltype);

                           if (window.XMLHttpRequest)
                           {// code for IE7+, Firefox, Chrome, Opera, Safari
                               xmlhttp = new XMLHttpRequest();
                           }
                           else
                           {// code for IE6, IE5
                               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                           }
                         //   alert("Hello Again "+processID);

                           xmlhttp.onreadystatechange = function ()
                           {
                               if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                               {
                                   document.getElementById("ViewlanguageDetails").innerHTML = xmlhttp.responseText;
                               }
                           }
                           document.getElementById("ViewlanguageDetails").style.display = "block";
                           xmlhttp.open("GET", "getLanguage.php?q=" + ltype, true);
                           xmlhttp.send();


                   });
                   
                
             });
            
        