/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



            $('#my_modal1').on('show.bs.modal', function(e) {
             // alert("abhay");
             var patientID = $(e.relatedTarget).data('process-id');
            //  $(e.currentTarget).find('label[id="lblprocess"]').text(patientID);
       
                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                // alert("Hello Again "+patientID);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("patientlist1").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("patientlist1").style.display = "block";
                xmlhttp.open("GET", "../support/getPatientDetails3.php?type=patientID&q=" + patientID+"", true);
                xmlhttp.send();
           
       
        });
      