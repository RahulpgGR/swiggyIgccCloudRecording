/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//$(".openpanel").on("click", function() {
//    $("#panel3").collapse('show');
//});
//$(".closepanel").on("click", function() {
//    $("#panel3").collapse('hide');
//});
//
//
//$('#accordion').on('show.bs.collapse', function () {
//    $('#accordion .in').collapse('hide');
//});

function showReport(str)
{
    // alert("Hello "+str);

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // alert("Hello Again "+str);

    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
        }
    }
    document.getElementById("divInfo").style.display = "block";
    
    xmlhttp.open("GET", "getDailyReport.php?q=" + str, true);
    xmlhttp.send();

}


function showReport1(str)
{
    // alert("Hello "+str);

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // alert("Hello Again "+str);

    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
        }
    }
    document.getElementById("divInfo").style.display = "block";
    xmlhttp.open("GET", "getRetentionReport.php?q=" + str, true);
    xmlhttp.send();

}


function showReport2(str)
{
    // alert("Hello "+str);

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // alert("Hello Again "+str);

    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
        }
    }
    document.getElementById("divInfo").style.display = "block";
    xmlhttp.open("GET", "getDailyNCReport.php?q=" + str, true);
    xmlhttp.send();

}

function showReport3(str)
{
  // alert("Hello "+str);

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // alert("Hello Again "+str);

    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
       //     document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
        }
    }
    // document.getElementById("divInfo").style.display = "block";
    xmlhttp.open("GET", "captureSession.php?q=" + str, true);
    xmlhttp.send();
}

/*
function captureDateSession(str,v)
{
    //   alert("Hello "+str);
    
    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    // alert("Hello Again "+str);

    xmlhttp.onreadystatechange = function ()
    {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
        //    document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
        }
    }

    if(v == 'SD')
        xmlhttp.open("GET", "../support/captureSession.php?v=CustDumpSDate&q=" + str, true);
    else
        xmlhttp.open("GET", "../support/captureSession.php?v=CustDumpEDate&q=" + str, true);

    xmlhttp.send();

}

function captureGradeStatusSession(str)
            {
              //   alert("Hello "+str);

                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                // alert("Hello Again "+str);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                    //    document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
                    }
                }
            //    document.getElementById("divInfo").style.display = "block";
                xmlhttp.open("GET", "../support/captureSession.php?v=GradeStatus&q=" + str, true);
                xmlhttp.send();
            
            }
            
            
function showCustomerlist(str)
            {
              //   alert("Hello "+str);

                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                // alert("Hello Again "+str);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("divInfo").style.display = "block";
                xmlhttp.open("GET", "../support/listCustomerSearch.php?q=" + str, true);
                xmlhttp.send();
            
            }
            

function showReport1(str)
            {
              //   alert("Hello "+str);

                if (window.XMLHttpRequest)
                {// code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                }
                else
                {// code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                // alert("Hello Again "+str);

                xmlhttp.onreadystatechange = function ()
                {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                    {
                        document.getElementById("divInfo").innerHTML = xmlhttp.responseText;
                    }
                }
                document.getElementById("divInfo").style.display = "block";
                xmlhttp.open("GET", "getdailyDashboard.php?q=" + str, true);
                xmlhttp.send();
            
            }
            

       
            
       


function showDivCustomer()
{
    $("#divCustomer").show();
    $("#divBroker").hide();
}

function showDivBroker()
{
    $("#divCustomer").hide();
    $("#divBroker").show();
}


function showSearch()
{
    
    $("#divSearchCriteria").show();
}

function showProfilePage(str)
{
   // alert(str);
    // $("#divProfile").show();
    
    if(str == 'Place Order')
    {
        $("#divProfile").show();
        $("#divbtncalldetails").hide();
    }
    else
    {
        $("#divProfile").hide();
        $("#divbtncalldetails").show();
    }
}

function showOrderConfirmatonDetailsPage(str)
{
   // alert(str);
    // $("#divProfile").show();
    
    if(str == 'Order Confirmed')
    {
        $("#collapseThree").show();
        $("#divbtncalldetails").hide();
    }
    else
    {
        $("#collapseThree").hide();
        $("#divbtncalldetails").show();
    }
}

function hideSearch()
{
    
    $("#divSearchCriteria").hide();
    $("#divPatientID").hide();
    $("#divPatientName").hide();
    $("#divPinCode").hide();
    $("#divPhone").hide();
    $("#divCustInfo").hide();
}


function showChequeDiv()
{
    $('#divChNo').show();
    $('#divChDt').show();
    $('#divChBank').show();
}

function hideChequeDiv()
{
    $('#divChNo').hide();
    $('#divChDt').hide();
    $('#divChBank').hide();
}

function showDivPatientID()
{
    $("#divPatientID").show();
    $("#divPatientName").hide();
    $("#divPinCode").hide();
    $("#divPhone").hide();
    $('#divCustInfo').hide();
}

function showDivNamePin()
{
    $("#divPatientID").hide();
    $("#divPatientName").show();
    $("#divPinCode").show();
    $("#divPhone").hide();
    $('#divCustInfo').hide();
}

function showDivPhone()
{
    $("#divPatientID").hide();
    $("#divPatientName").hide();
    $("#divPinCode").hide();
    $("#divPhone").show();
    $('#divCustInfo').hide();
}

function validateOrderConfCallform()
{
    return true;
}

function validatecallform()
{
    // alert("Abhay");
    // alert(document.forms["frm2"]["inlineRadioOptions"].value);
    
    if(document.forms["frm2"]["inlineRadioOptions"].value == "Yes")
    {
        if(document.forms["frm2"]["inlineRadioOptions1"].value == "")
        {
            alert("Please Select the Search Criteria Option");            
            return false;
        }
        else
        {
            if(document.forms["frm2"]["inlineRadioOptions1"].value == "PID")
            {
                if(document.forms["frm2"]["txtPatientID"].value == "")
                {
                    alert("Please Enter the Patient ID");  
                    document.forms["frm2"]["txtPatientID"].focus();
                    return false;
                } 
                if(document.forms["frm2"]["txtPatientDetails"].value == "Patient Record Not Available")
                {
                    alert("Please Enter the Correct Patient ID or Click 'No' for Existing Patient");  
                   // document.forms["frm2"]["txtPatientID"].focus();
                    return false;
                } 
            }
            else if(document.forms["frm2"]["inlineRadioOptions1"].value == "NamePin")
            {
                if(document.forms["frm2"]["txtPatientName1"].value == "")
                {
                    alert("Please Enter the Patient Name"); 
                    document.forms["frm2"]["txtPatientName1"].focus();
                    return false;
                }
                
                if(document.forms["frm2"]["txtPatientPinCode"].value == "")
                {
                    alert("Please Enter the Patient PinCode");
                    document.forms["frm2"]["txtPatientPinCode"].focus();
                    return false;
                } 
                
                if(document.forms["frm2"]["txtPatientDetails"].value == "Patient Record Not Available")
                {
                    alert("Please Enter the Correct Patient Name and Pin Code or Click 'No' for Existing Patient");  
                   // document.forms["frm2"]["txtPatientID"].focus();
                    return false;
                } 
            }
            else
            {
                if(document.forms["frm2"]["txtRegPhoneNumber"].value == "")
                {
                    alert("Please Enter the Registered Number");  
                    document.forms["frm2"]["txtRegPhoneNumber"].focus();
                    return false;
                } 
                                
                if(document.forms["frm2"]["txtPatientDetails"].value == "Patient Record Not Available")
                {
                    alert("Please Enter the Correct Regsistered Phone Number or Click 'No' for Existing Patient");  
                   // document.forms["frm2"]["txtPatientID"].focus();
                    return false;
                } 
            }
           
            
        }
    }
        
    if(document.forms["frm2"]["txtCallerName"].value == "")
    {
        alert("Please Enter the Caller Name");
        document.forms["frm2"]["txtCallerName"].focus();
        return false;
    }
    
    if(document.getElementById("ddCallReason").options[ddCallReason.selectedIndex].value == "")
    {
        alert("Please Select the Call Reason");
        document.forms["frm2"]["ddCallReason"].focus();
        return false;
    }
    
    if(document.getElementById("ddCallDisposition").options[ddCallDisposition.selectedIndex].value == "")
    {
        alert("Please Select the Call Disposition");
        document.forms["frm2"]["ddCallDisposition"].focus();
        return false;
    }
    
    if(document.getElementById("ddCallReason").options[ddCallReason.selectedIndex].value == "Place Order")
    {
        
  //  alert("Vaidya");
 //  alert(document.forms["frm2"]["txtPatientName"].value);
//    return true;
    
    // alert(document.getElementById("ddCustomerIssue").options[ddCustomerIssue.selectedIndex].value);
    
    
    if(document.forms["frm2"]["txtPatientName"].value==null || document.forms["frm2"]["txtPatientName"].value=="")
    {          
        alert("Please Enter the Patient Name");
        document.forms["frm2"]["txtPatientName"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtAge"].value==null || document.forms["frm2"]["txtAge"].value=="")
    {          
        alert("Please Enter the Patient Age");
        document.forms["frm2"]["txtAge"].focus();
        return false;
    }
    
    if(document.getElementById("ddGender").options[ddGender.selectedIndex].value == "")
    {
        alert("Please Select the Gender");
        document.forms["frm2"]["ddGender"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtContactNo"].value==null || document.forms["frm2"]["txtContactNo"].value=="")
    {          
        alert("Please Enter the Contact Number");
    //    document.forms["frm2"]["txtContactNo"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtAddress"].value==null || document.forms["frm2"]["txtAddress"].value=="")
    {          
        alert("Please Enter the Address");
    //    document.forms["frm2"]["txtAddress"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtCity"].value==null || document.forms["frm2"]["txtCity"].value=="")
    {          
        alert("Please Enter the City");
    //    document.forms["frm2"]["txtCity"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtPincode"].value==null || document.forms["frm2"]["txtPincode"].value=="")
    {          
        alert("Please Enter the Pincode");
    //    document.forms["frm2"]["txtPincode"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtHospital"].value==null || document.forms["frm2"]["txtHospital"].value=="")
    {          
        alert("Please Enter the Hospital Name");
    //    document.forms["frm2"]["txtHospital"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtDoctor"].value==null || document.forms["frm2"]["txtDoctor"].value=="")
    {          
        alert("Please Enter the Doctor Name");
    //    document.forms["frm2"]["txtDoctor"].focus();
        return false;
    }
    
    if(document.getElementById("ddCondition").options[ddCondition.selectedIndex].value == "")
    {
        alert("Please Select the Patient Condition");
    //    document.forms["frm2"]["ddCondition"].focus();
        return false;
    }
    
    if(document.getElementById("ddUsage").options[ddUsage.selectedIndex].value == "")
    {
        alert("Please Select the Usage");
    //    document.forms["frm2"]["ddUsage"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtIssue"].value==null || document.forms["frm2"]["txtIssue"].value=="")
    {          
        alert("Please Enter the Issue / Prescription");
    //    document.forms["frm2"]["txtIssue"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtDuration"].value==null || document.forms["frm2"]["txtDuration"].value=="")
    {          
        alert("Please Enter the Duration");
    //    document.forms["frm2"]["txtDuration"].focus();
        return false;
    }
    
    if(document.forms["frm2"]["txtInstallationDate"].value==null || document.forms["frm2"]["txtInstallationDate"].value=="")
    {          
        alert("Please Enter the Installation Date");
        // document.forms["frm2"]["txtInstallationDate"].focus();
        return false;
    }
    if(document.forms["frm2"]["product"][0].checked==false &&
            document.forms["frm2"]["product"][1].checked==false &&
            document.forms["frm2"]["product"][2].checked==false)
    {          
        alert("Please Select atleast One Product");
    //    document.forms["frm2"]["product"][0].focus();
        return false;
    } 
    
//    if(document.getElementById("ddDisposition").options[ddDisposition.selectedIndex].value == "")
//    {
//        alert("Please Select the Disposition");
//        document.forms["frm2"]["ddDisposition"].focus();
//        return false;
//    }
}
}


function validatecallDialerform()
{
    // alert("Abhay");
    // alert(document.forms["frm1"]["inlineRadioOptions"].value);
    
    if(document.forms["frm1"]["txtCallerName"].value == "")
    {
        alert("Please Enter the Caller Name");
        document.forms["frm1"]["txtCallerName"].focus();
        return false;
    }
    
    if(document.getElementById("ddCallReason").options[ddCallReason.selectedIndex].value == "")
    {
        alert("Please Select the Call Reason");
        document.forms["frm1"]["ddCallReason"].focus();
        return false;
    }
    
    if(document.getElementById("ddCallDisposition").options[ddCallDisposition.selectedIndex].value == "")
    {
        alert("Please Select the Call Disposition");
        document.forms["frm1"]["ddCallDisposition"].focus();
        return false;
    }
    
    if(document.getElementById("ddCallDisposition").options[ddCallDisposition.selectedIndex].value == "Place Order")
    {
        
 //   alert("Abhay");
//    return true;
    
    // alert(document.getElementById("ddCustomerIssue").options[ddCustomerIssue.selectedIndex].value);
    
    
    if(document.forms["frm1"]["txtPatientName"].value==null || document.forms["frm1"]["txtPatientName"].value=="")
    {          
        alert("Please Enter the Patient Name");
        document.forms["frm1"]["txtPatientName"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtAge"].value==null || document.forms["frm1"]["txtAge"].value=="")
    {          
        alert("Please Enter the Patient Age");
    //    document.forms["frm1"]["txtAge"].focus();
        return false;
    }
    
    if(document.getElementById("ddGender").options[ddGender.selectedIndex].value == "")
    {
        alert("Please Select the Gender");
     //   document.forms["frm1"]["ddGender"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtContactNo"].value==null || document.forms["frm1"]["txtContactNo"].value=="")
    {          
        alert("Please Enter the Contact Number");
    //    document.forms["frm1"]["txtContactNo"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtAddress"].value==null || document.forms["frm1"]["txtAddress"].value=="")
    {          
        alert("Please Enter the Address");
    //    document.forms["frm1"]["txtAddress"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtCity"].value==null || document.forms["frm1"]["txtCity"].value=="")
    {          
        alert("Please Enter the City");
    //    document.forms["frm1"]["txtCity"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtPincode"].value==null || document.forms["frm1"]["txtPincode"].value=="")
    {          
        alert("Please Enter the Pincode");
    //    document.forms["frm1"]["txtPincode"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtHospital"].value==null || document.forms["frm1"]["txtHospital"].value=="")
    {          
        alert("Please Enter the Hospital Name");
    //    document.forms["frm1"]["txtHospital"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtDoctor"].value==null || document.forms["frm1"]["txtDoctor"].value=="")
    {          
        alert("Please Enter the Doctor Name");
    //    document.forms["frm1"]["txtDoctor"].focus();
        return false;
    }
    
    if(document.getElementById("ddCondition").options[ddCondition.selectedIndex].value == "")
    {
        alert("Please Select the Patient Condition");
    //    document.forms["frm1"]["ddCondition"].focus();
        return false;
    }
    
    if(document.getElementById("ddUsage").options[ddUsage.selectedIndex].value == "")
    {
        alert("Please Select the Usage");
    //    document.forms["frm1"]["ddUsage"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtIssue"].value==null || document.forms["frm1"]["txtIssue"].value=="")
    {          
        alert("Please Enter the Issue / Prescription");
    //    document.forms["frm1"]["txtIssue"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtDuration"].value==null || document.forms["frm1"]["txtDuration"].value=="")
    {          
        alert("Please Enter the Duration");
    //    document.forms["frm1"]["txtDuration"].focus();
        return false;
    }
    
    if(document.forms["frm1"]["txtInstallationDate"].value==null || document.forms["frm1"]["txtInstallationDate"].value=="")
    {          
        alert("Please Enter the Installation Date");
        // document.forms["frm1"]["txtInstallationDate"].focus();
        return false;
    }
    if(document.forms["frm1"]["product"][0].checked==false &&
            document.forms["frm1"]["product"][1].checked==false &&
            document.forms["frm1"]["product"][2].checked==false)
    {          
        alert("Please Select atleast One Product");
    //    document.forms["frm1"]["product"][0].focus();
        return false;
    } 
    
//    if(document.getElementById("ddDisposition").options[ddDisposition.selectedIndex].value == "")
//    {
//        alert("Please Select the Disposition");
//        document.forms["frm1"]["ddDisposition"].focus();
//        return false;
//    }
}
}*/