function channel()
{
    organisation_name = $("#organisation_name").val();
    name = $("#name").val();
    pan_card_no = $("#pan_card_no").val();
    address = $("#address").val();
    email = $("#email").val();
    phone_number = $("#phone_number").val();
    id_proof = $("input[id='id_proof']").serializeArray();
    terms_condition = $("#terms_condition").prop("checked");
   // temp_phone_no = "([0-9]{10})|(\([0-9]{3}\)\s+[0-9]{3}\-[0-9]{4})";
    var error = 0;
    if (organisation_name == "")
    {
        error++;
        $("#organisation_name").css({"border": "2px solid #ff0000", "box-shadow": "0 0 3px #ff0000"});
    } else
    {
        $("#organisation_name").css({"border": "", "box-shadow": ""});
    }
    if (name == "")
    {
        error++;
        $("#name").css({"border": "2px solid #ff0000", "box-shadow": "0 0 3px #ff0000"});
    } else
    {
        $("#name").css({"border": "", "box-shadow": ""});
    }
     if (pan_card_no == "")
    {
        error++;
        $("#pan_card_no").css({"border": "2px solid #ff0000", "box-shadow": "0 0 3px #ff0000"});
    } else
    {
        $("#pan_card_no").css({"border": "", "box-shadow": ""});
    }
    if (address == "")
    {
        error++;
        $("#address").css({"border": "2px solid #ff0000", "box-shadow": "0 0 3px #ff0000"});
    } else
    {
        $("#address").css({"border": "", "box-shadow": ""});
    }
    if (email == "")
    {
        error++;
        $("#email").css({"border": "2px solid #ff0000", "box-shadow": "0 0 3px #ff0000"});
    } else
    {
        $("#email").css({"border": "", "box-shadow": ""});
    }
    if (phone_number == "")
    {
        error++;
        $("#phone_number").css({"border": "2px solid #ff0000", "box-shadow": "0 0 3px #ff0000"});
        $("#phone_no_error").html("The Phone Number have only Numeric");
    } else
    {
        $("#phone_number").css({"border": "", "box-shadow": ""});
        $("#phone_no_error").html("");
    }
    if (id_proof == false)
    {
        error++;
        $("#id_proof_error").css({"display": "block", "float": "left"});
        $("#id_proof_error").html("Please Select the ID Proof");
    } else
    {
        $("#id_proof_error").css("display", "none");
        $("#id_proof_error").html("");
    }
    if (id_proof.length == 0)
    {
        error++;
        $("#id_proof_error").css({"display": "block", "float": "left"});
        $("#id_proof_error").html("Please Select the ID Proof");
    } else
    {
        $("#id_proof_error").css("display", "none");
        $("#id_proof_error").html("");
    }
    if (terms_condition == false)
    {
        error++;
       // $("#terms_condition_error").css({"display": "block", "float": "left"});
        $("#terms_condition_error").html("Please agree to the Terms & Conditions");
    } else
    {
        $("#terms_condition_error").css("display", "none");
        $("#terms_condition_error").html("");
    }
    // alert(terms_condition);   
   if(error > 0)
   {
       return false;
   }
}

//Click Image Uploaded
$(document).ready(function () {
    $("#profile_image").click(function () {
        $("input[id='my_file']").click();
    });


});
$(document).ready(function () {
    $("#visiting_card").click(function () {
        $("input[id='my_vist']").click();
    });
});
//onchange Image upload showing images
$(function () {

    $("#my_file").on("change", function () {
        //alert("hi");
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader)
            return;
        if (/^image/.test(files[0].type)) { // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function () { // set image data as background of div
                $("#profile_image").css("background-image", "url(" + this.result + ")");
            }
        }
    });
});

$(function () {

    $("#my_vist").on("change", function () {
        //alert("hi");
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader)
            return;
        if (/^image/.test(files[0].type)) { // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file

            reader.onloadend = function () { // set image data as background of div
                $("#visiting_card").css("background-image", "url(" + this.result + ")");
            }
        }
    });
});