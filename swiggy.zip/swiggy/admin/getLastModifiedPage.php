<?php

require_once '/var/www/html/staging/swiggy_Record_Details/services_Logging.php';
    $log = new Logging();

    $log->lfile('/var/www/html/staging/swiggy_Record_Details/log/Swiggy_RecordFileNames_logfile'.date('Ymd').'.txt');

    $log->lwrite("===================================================");
    $log->lwrite("Welcome to push the record files names to database");
	
	
	include_once '../db/db_connect.php';
	$db = new db();
	$con = $db->connect();
	if($con){
		echo "databse connected successfully <br>";
		$log->lwrite("===================================================");
			$log->lwrite(" Data Base connected Successfully ");
	}
	else{
		echo "no database";
		$log->lwrite("===================================================");
			$log->lwrite(" Data Base not  connected ");
	}
	
	$sql1="call SP_GetLastUpdaeteTime()";
	$result1=$db->select($sql1);
	foreach($result1 as $row1){
		$etime = strtotime($row1['date2']);
		$log->lwrite("===================================================");
		$log->lwrite("=======".$sql1."========");
			$log->lwrite(" last data inserted daettime is  ".$row1['date2']."===".$etime));
	}
	
	$d1=scandir('records/');
	$i=0;
	$files=array_diff($d1, array('.', '..'));
		foreach ($files as $file) 
		{
			echo "files are exits";
			$fdate = filemtime("records/".$file);
			if($fdate > $etime)
			{
			echo "<br> Files are there inside if condition";
				echo $file . "<br>";
				$i++;
				$parts = explode("-", $file);
				$q_uinque = $parts[5];

                    $q_uinque_no1 = explode('.', $q_uinque);
					$q_uinque_first = $q_uinque_no1[0];
					$q_uinque_sec = $q_uinque_no1[1];
				    $q_uinque_exten = $q_uinque_no1[2];
				   
                    $uniqueid = $q_uinque_first . "." . $q_uinque_sec;
					
				while(mysqli_more_results($con)){mysqli_next_result($con);}
				echo $sql="call SP_swiggy_Record_Filenames_Insert('$file','$uniqueid')";
				echo "<br> ".$sql;
				$result=$db->query($sql);
				if($result)
				{
					foreach($result as $row){
						if($row['result'] == 0 ){
						$log->lwrite("===================================================");
						$log->lwrite("Data already inserted Successfully Filename  ".$file ." ----" .$uniqueid);
						}
						else{
							$log->lwrite("===================================================");
							$log->lwrite("Data inserted Successfully Filename  ".$file ." ---- ".$uniqueid);
						
						}
				}
				}
				else{
					$log->lwrite("===================================================");
						$log->lwrite("Filename is not moved to folder ---- ".$file ." ---- ". $uniqueid ."-------" .$db->error());
				}
				
			}
		}
			$log->lwrite("===================================================");
			$log->lwrite("Cron run successfully ".$file ." ---- ". $uniqueid);
			//$log.close();
?>
		
		
		