<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(!isset($_SESSION)) {
    session_start();
}
include_once 'db/db_connect.php';
$db = new db();
$con = $db->connect();
if (!isset($_SESSION['UserName'])) {
    header("location:login/");
}
$AgentName = $_SESSION['UserName'];
?>

<!DOCTYPE html>
<html lang="en">                   
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Leads Management Platform">
        <meta name="author" content="Grassroots BPO Pvt Ltd">
        <title>Swiggy- Grassroots Platform</title>
        <link rel="icon" href="favi.png" type="image/x-icon"/>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="css/font-awesome.minFin.css"> -->
        
        <link rel="stylesheet" href="css/jquery-ui.css"> 
     <link rel="stylesheet" href="css/jquery.datetimepicker.css"> 
        <link rel="stylesheet" href="css/font-awesome.min.css">
        
        <script  src="js/jquery-3.3.1.js"></script>
        <script   src="js/jquery-ui12.js"></script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Optional theme -->
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/gr.css">
        <link rel="stylesheet" href="css/AdminLTE.min.css">
         
    <!--<link href="../css/login.css" rel="stylesheet">-->
        <script src="js/grmnp.js"></script> 
        <link rel="stylesheet" href="css/fab.css">
        <style>
            body {
                margin-top: 60px;
                -webkit-background-size: cover;
                -moz-background-size: cover;
                -o-background-size: cover;
                background-size: cover;
                background-color: #fffff0;
      }
      form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}
* {
  box-sizing: border-box;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
} 
      
        </style>

<style>
.loader {
    display: none;
    margin: 0 0 0 46%;
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
    </head>
    <body>
      <style type="text/css">
          label {
            font-weight: 800;
            color: darkseagreen;
          }
          
        </style>
      
        
      
  <div class="container">
        <nav class="navbar navbar-default navbar-fixed-top mybg"> 
            <div class="container-fluid"> 
                <div class="navbar-header"> 
                                         
                    <a href="index.php">
                      <img  src="images/swiggy-logo.png" style='padding-top: 0.75em;width: 112px;padding-bottom: 7px;'/></a>
                </div> 
               <?php 
                $url=$audio='';
                ?>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right"> 
                      <!-- <li>
                          <a  href="up LeadDetails.php" style="color: blueviolet; font-weight: bold;">Manage Leads</a>
                      </li> -->
                      <li>
                          <a style="color: gray; font-weight: bold;">Welcome <?php echo $AgentName; ?></a>
                      </li> 
                      <li>
                          <a href="logout.php"style="color: gray; font-weight: bold;">LogOut</a>
                      </li> 
                    <li style="margin-top: 14px;"><object type="image/svg+xml" data="images/gr2.svg" width="120px">
                                </object>
                        </li>
                    </ul>                         
                </div>                     
            </div>                 
        </nav>
        <br>
        <div class="row">
            
                <div class="col-sm-12">
                    <div>
                        <div class="box-body">
                            <h4 style="text-align:center;color:green;">Search Record Details</h4>
                            <hr>
                            <form>
                                <div style="text-align:center;">
                                    <label>Mobile Number</label>
                                    <input type="text" placeholder="Enter Mobile Number" name="mblnumber" id="mblnumber">
                                    
                                    <label>Order ID</label>
                                    <input type="text" placeholder="Enter Order ID" name="orderid" id="orderid">
                                    
                                    <input type="button" onclick="get_record_details();" class="btn btn-success" value="Search">
                                    <!-- <button type="button" onclick="get_record_details();" class="btn btn-success center-block">Search</button> -->
                                </div>
                            </form>
                        </div>

                    </div>
                    <br><br>
                             
                </div>
            <div class="col-sm-12">
                <div class="loader"></div>
            <br/>
            <div id="record_details"></div>
            </div>
        </div>        
<style type="text/css">
    button
    {
        text-align: :center;
        width: 43%;
    }
</style>    
<script>
// function get_record_detailsras() {
//     $(".loader").show();
//     // get_record_detailsras();
// }


function get_record_details() {
    // $(".loader").hide();
    orderid=document.getElementById('orderid').value;
    //alert(orderid);
    mblnumber=document.getElementById('mblnumber').value;
   //alert(mblnumber);
     $.ajax({
                        url: "ajax_response.php?q1="+orderid+ "&q2=" +mblnumber,
                        dataType: "text",
                        type: "post",
                        processData: false,
                        contentType: false,
                        async: false,
                        cache: false,
                        success: function (data){                             
                                $("#record_details").html(data);
                        }
                    });
                    // get_record_detailsras();
  }

</script> 
<nav class="navbar navbar-brand navbar-fixed-bottom" role="navigation">
  <div class="text-center" >
    <h5>Powered by Grassroots</h5>
  </div>
</nav>
</div>


<script src="js/adminlte.min.js"></script>
     <style>
   #form_label label{
     color: #b12119;
   }
   
   </style>
    </body>
</html>

