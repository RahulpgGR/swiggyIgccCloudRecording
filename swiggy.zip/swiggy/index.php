<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(!isset($_SESSION)) {
    session_start();
}
include_once 'db/db_connect.php';
$db = new db();
$con = $db->connect();
// if (!isset($_SESSION['UserName'])) {
//     header("location:login/");
// }
// $AgentName = $_SESSION['UserName'];

$AgentName = 'Rahul';
?>

<!DOCTYPE html>
<html lang="en">                   
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Leads Management Platform">
        <meta name="author" content="Grassroots BPO Pvt Ltd">
        <title>Swiggy- Grassroots Platform</title>
        <link rel="icon" href="favi.png" type="image/x-icon"/>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- <link rel="stylesheet" href="css/font-awesome.minFin.css"> -->
        
        <link rel="stylesheet" href="css/jquery-ui.css"> 
     <link rel="stylesheet" href="css/jquery.datetimepicker.css"> 
        <link rel="stylesheet" href="css/font-awesome.min.css">
        
        <script  src="js/jquery-3.3.1.js"></script>
        <script   src="js/jquery-ui12.js"></script>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Optional theme -->
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/gr.css">
        <link rel="stylesheet" href="css/AdminLTE.min.css">
         
    <!--<link href="../css/login.css" rel="stylesheet">-->
        <script src="js/grmnp.js"></script> 
        <link rel="stylesheet" href="css/fab.css">
        <style>
            body {
                margin-top: 60px;
                -webkit-background-size: cover;
                -moz-background-size: cover;
                -o-background-size: cover;
                background-size: cover;
                background-color: #fffff0;
      }
      form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}
* {
  box-sizing: border-box;
}

form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
} 
      
        </style>

<style>
.loader {
    display: none;
    margin: 0 0 0 46%;
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
    </head>
    <body>
      <style type="text/css">
          label {
            font-weight: 800;
            color: darkseagreen;
          }
          
        </style>
      
        
      
  <div class="container">
        <nav class="navbar navbar-default navbar-fixed-top mybg"> 
            <div class="container-fluid"> 
                <div class="navbar-header"> 
                                         
                    <a href="index.php">
                      <img  src="images/swiggy-logo.png" style='padding-top: 0.75em;width: 112px;padding-bottom: 7px;'/></a>
                </div> 
               <?php 
                $url=$audio='';
                ?>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right"> 
                      <!-- <li>
                          <a  href="up LeadDetails.php" style="color: blueviolet; font-weight: bold;">Manage Leads</a>
                      </li> -->
                      
                      <li>
                          <a style="color: gray; font-weight: bold;">Welcome <?php echo $AgentName; ?></a>
                      </li> 
                      
                      <li>
                          <a href="logout.php"style="color: gray; font-weight: bold;">LogOut</a>
                      </li> 
                    
                    <li style="margin-top: 14px;"><object type="image/svg+xml" data="images/gr2.svg" width="120px">
                                </object>
                    </li>

                    </ul>                         
                </div>                     
            </div>                 
        </nav>
        <br>
        <div class="row">
            
                <div class="col-sm-12">
                    <div>
                        <div class="box-body">
                            <h4 style="text-align:center;color:green;">Dilaer Calls - Search Record Details</h4>
                            <hr>
                            <form>
                                <div style="text-align:center;">

                                  <div class="row">
                                    
                                    <div class="col-md-4"></div>

                                    <div class="col-md-2">
                                    <label>From  Date</label>
                                    <!--<input type="date" class="form-control from_date" id="from_date" name="from_date" >-->
                                    
                                    <input type="text" class="form-control from_date" id="from_date" name="from_date" value='<?php echo date('Y-m-d')?>'>
                                    </div> 

                                    <div class="col-md-2">
                                    <label>To  Date</label>
                                    <!--<input type="date" class="form-control to_date" id="to_date" name="to_date"  >-->

                                     <input type="text" class="form-control to_date" id="to_date" name="to_date" value='<?php echo date('Y-m-d')?>'>
                                    </div> 

                                   <div class="col-md-4"></div>

                                  </div>   

                                  <div class="row"></div>

                                    <label>Mobile Number</label>
                                    <input type="text" placeholder="Enter Mobile Number" name="mblnumber" id="mblnumber">
                                    
                                    <label>Order ID</label>
                                    <input type="text" placeholder="Enter Order ID" name="orderid" id="orderid">

                                    <select name="agentid" id="agent_id_list" required   >
                                    <option value="0">Agent</option>
                                    <?php
                                    include_once 'db/db_connect.php';     
                                    $db = new db();
                                    $con = $db->connect();
                                    while(mysqli_more_results($con)){mysqli_next_result($con);}
                                    $sqls="SELECT agentform,agentname FROM Record_Filenames";
                                    $results=$db->select($sqls);
                                    foreach($results as $list):
                                    ?>
                                    <option value="<?php echo $list['agentform']?>"><?php echo $list['agentform']?></option>
                                    
                                    <?php endforeach; ?>

                                    </select>
                                    
                                    <input type="button" onclick="get_record_details('q');" class="btn btn-success" value="Search">
                                    <!-- <button type="button" onclick="get_record_details();" class="btn btn-success center-block">Search</button> -->
                                </div>
                            </form>
                        </div>

                    </div>
                    <br><br>
                             
                </div>
                
                <div class="col-sm-12">
                    <div>
                        <div class="box-body">
                            <h4 style="text-align:center;color:green;">Manual Calls - Search Record Details</h4>
                            <hr>
                            <form>
                                <div style="text-align:center;">

                                    <div class="row">
                                    
                                    <div class="col-md-4"></div>

                                    <div class="col-md-2">
                                    <label>From  Date</label>
                                    <!--<input type="date" class="form-control from_date" id="from_date1" name="from_date"  >-->

                                    <input type="text" class="form-control from_date" id="from_date1" name="from_date" value='<?php echo date('Y-m-d')?>'>

                                    </div> 

                                    <div class="col-md-2">
                                    <label>To  Date</label>
                                    <!--<input type="date" class="form-control to_date" id="to_date1" name="to_date">-->

                                    <input type="text" class="form-control to_date" id="to_date1" name="to_date" value='<?php echo date('Y-m-d')?>'>
                                    </div> 

                                   <div class="col-md-4"></div>

                                  </div>  


                                    <label>Mobile Number</label>
                                    <input type="text" placeholder="Enter Mobile Number" name="mblnumber" id="mblnumbers">

                                    <label>Order ID</label>
                                    <input type="text" placeholder="Enter Order ID" name="orderid" id="orderid_manual">

                                    <!-- <input type="text" placeholder="Enter Agent Id" name="agentid" id="agent_id_manul"> -->

                                    <select name="agentid" id="agent_id_manul"  required  >
                                    <option value="0">Select Extension</option>
                                    <?php
                                    include_once 'db/db_connect.php';     
                                    $db = new db();
                                    $con = $db->connect();
                                    while(mysqli_more_results($con)) {mysqli_next_result($con);}
                                    $sqls="SELECT agentform,agentname FROM Record_Filenames";
                                    $results=$db->select($sqls);
                                    foreach($results as $list):
                                    ?>
                                      <option value="<?php echo $list['agentform']?>"><?php echo $list['agentform']?></option>
                                    
                                    <?php endforeach; ?>

                                    </select>

                                  <input type="button" onclick="get_record_details('out')" class="btn btn-success" value="Search">


                                    <!-- <button type="button" onclick="get_record_details();" class="btn btn-success center-block">Search</button> -->
                                </div>
                            </form>
                        </div>

                    </div>
                    <br><br>
                             
                </div>
            <div class="col-sm-12">
                <div class="loader"></div>
            <br/>
            <div id="record_details"></div>
            </div>
        </div>        
<style type="text/css">
    button
    {
        text-align: :center;
        width: 43%;
    }
</style>    
<script>
// function get_record_detailsras() {
//     $(".loader").show();
//     // get_record_detailsras();
// }


function get_record_details(res) {
    // $(".loader").hide();


    if(res == 'q') {

    orderid=document.getElementById('orderid').value;
        //alert(orderid);
    mblnumber=document.getElementById('mblnumber').value;
    //alert(mobilenumber);
    agentid=document.getElementById('agent_id_list').value;
      
     alert(agentid);

    var text_start_date = $(".from_date").val();
    var text_end_date = $(".to_date").val();

    // alert(text_start_date);
    // alert(text_end_date);

        $.ajax({
            url: "ajax_response.php?q1="+orderid+ "&q2=" +mblnumber+ "&q=" +res+'&agentid='+agentid+
            '&start_date='+text_start_date+'&from_date='+text_end_date,
            dataType: "text",
            type: "post",
            processData: false,
            contentType: false,
            async: false,
            cache: false,
            success: function (data){                             
                $("#record_details").html(data);
            }
        });
    }
    
    if(res == 'out') {
        orderid='';

        var text_start_date = $("#from_date1").val();
        var text_end_date  =  $("#to_date1").val();

        agentid=document.getElementById('agent_id_manul').value;
        //alert(orderid);
        mblnumber=document.getElementById('mblnumbers').value;
        alert(mblnumber);
          
        orderid=document.getElementById('orderid_manual').value;  
          
    alert(agentid);

   // alert(text_start_date);

   // alert(text_end_date);

        $.ajax({
            url: "ajax_response.php?q1="+orderid+ "&q2=" +mblnumber+ "&q=" +res+'&agentid='+agentid+
            '&start_date='+text_start_date+'&from_date='+text_end_date,
            dataType: "text",
            type: "post",
            processData: false,
            contentType: false,
            async: false,
            cache: false,
            success: function (data){                             
                $("#record_details").html(data);
            }
        });
    }
    // get_record_detailsras();
  }

</script> 

<script>
function GetAudioFile(ras,ras1) {
//    alert(ras);
//    alert(ras1);
   var error = 0;
        if (error == 0){
            window.location.href = "http://14.98.23.206/staging/swiggy_Record_Details/"+ras+"/"+ras1;
        }
}
</script>

<nav class="navbar navbar-brand navbar-fixed-bottom" role="navigation">
  <div class="text-center" >
    <h5>Powered by Grassroots</h5>
  </div>
</nav>
</div>


<link rel="stylesheet" type="text/css" href="css2/jquery.datetimepicker.css">
<link rel="stylesheet" type="text/css" href="css2/bootstrap-datetimepicker.min.css">
<script type="text/javascript" src="js2/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="js2/jquery-ui12.js"></script>
<script type="text/javascript" src="js2/jquery.datetimepicker.js"></script>
  
  

<script src="js/adminlte.min.js"></script>
     <style>
   #form_label label{
     color: #b12119;
   }
   
   </style>


<script>
$(function () {
    $(".to_date").datepicker({
        dateFormat: "yy-mm-dd",
        showOtherMonths: true,
        selectOtherMonths: true,
        autoclose: true,
        changeMonth: true,
        changeYear: true
        //gotoCurrent: true,
    });

   $(".from_date").datepicker({
        dateFormat: "yy-mm-dd",
        showOtherMonths: true,
        selectOtherMonths: true,
        autoclose: true,
        changeMonth: true,
        changeYear: true
        //gotoCurrent: true,
    });
});
</script>

    </body>
</html>

