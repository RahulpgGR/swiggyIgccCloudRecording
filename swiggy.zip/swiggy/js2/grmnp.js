/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
$(".openpanel").on("click", function() {
    $("#panel3").collapse('show');
});
$(".closepanel").on("click", function() {
    $("#panel3").collapse('hide');
});

/* ensure any open panels are closed before showing selected */
/*$('#accordion').on('show.bs.collapse', function () {
    $('#accordion .in').collapse('hide');
});
*/

function validateForm()
{
    // alert("Hello");
    // alert(document.getElementById("ddCustomerIssue").options[ddCustomerIssue.selectedIndex].value);
  
    if(document.getElementById("ddPortOutReason").options[ddPortOutReason.selectedIndex].value == "")
    {
        alert("Please Select the Port Out Reason");
        document.forms["frm1"]["ddPortOutReason"].focus();
        return false;
    }
    
    if(document.getElementById("ddPortOutSubReason").options[ddPortOutSubReason.selectedIndex].value == "")
    {
        alert("Please Select the Port Out Sub Reason");
        document.forms["frm1"]["ddPortOutSubReason"].focus();
        return false;
    }
    
    if(document.getElementById("ddDisposition").options[ddDisposition.selectedIndex].value == "")
    {
        alert("Please Select the Disposition");
        document.forms["frm1"]["ddDisposition"].focus();
        return false;
    }
    
    if(document.getElementById("ddDispositionDetails").options[ddDispositionDetails.selectedIndex].value == "")
    {
        alert("Please Select the Disposition Details");
        document.forms["frm1"]["ddDispositionDetails"].focus();
        return false;
    }
    
}


       
            
             $(function(){ 
          
                $('#my_modal1').on('show.bs.modal', function(e) {
                  //   alert("abhay");
                  var ltype = $(e.relatedTarget).data('lead1-id');
                  //     alert(ltype);
                    $(e.currentTarget).find('label[id="lblleadid"]').text(ltype);

                           if (window.XMLHttpRequest)
                           {// code for IE7+, Firefox, Chrome, Opera, Safari
                               xmlhttp = new XMLHttpRequest();
                           }
                           else
                           {// code for IE6, IE5
                               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                           }
                         //   alert("Hello Again "+processID);

                           xmlhttp.onreadystatechange = function ()
                           {
                               if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                               {
                                   document.getElementById("leaddetails").innerHTML = xmlhttp.responseText;
                               }
                           }
                           document.getElementById("leaddetails").style.display = "block";
                           xmlhttp.open("GET", "getLeadDetails.php?q=" + ltype+"&d=0", true);
                           xmlhttp.send();


                   });
                   
                   
                     $('#my_modal2').on('show.bs.modal', function(e) {
                  //  alert("abhay");
                    var ltype = $(e.relatedTarget).data('lead1-id');
                   //  alert(ltype);
                          //   $(e.currentTarget).find('label[id="lblleadid"]').text(ltype);

                           if (window.XMLHttpRequest)
                           {// code for IE7+, Firefox, Chrome, Opera, Safari
                               xmlhttp = new XMLHttpRequest();
                           }
                           else
                           {// code for IE6, IE5
                               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                           }
                         //   alert("Hello Again "+processID);

                           xmlhttp.onreadystatechange = function ()
                           {
                               if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                               {
                                   document.getElementById("leadUpdateForm").innerHTML = xmlhttp.responseText;
                               }
                           }
                           document.getElementById("leadUpdateForm").style.display = "block";
                           xmlhttp.open("GET", "updateStatusForm.php?q=" + ltype, true);
                           xmlhttp.send();


                   });
                   
                   $('#my_modal4').on('show.bs.modal', function(e) {
                  //  alert("abhay");
                    var ltype = $(e.relatedTarget).data('lead1-id');
                   //  alert(ltype);
                          //   $(e.currentTarget).find('label[id="lblleadid"]').text(ltype);

                           if (window.XMLHttpRequest)
                           {// code for IE7+, Firefox, Chrome, Opera, Safari
                               xmlhttp = new XMLHttpRequest();
                           }
                           else
                           {// code for IE6, IE5
                               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                           }
                         //   alert("Hello Again "+processID);

                           xmlhttp.onreadystatechange = function ()
                           {
                               if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                               {
                                   document.getElementById("leadCommentForm").innerHTML = xmlhttp.responseText;
                               }
                           }
                           document.getElementById("leadCommentForm").style.display = "block";
                           xmlhttp.open("GET", "addComments.php?q=" + ltype, true);
                           xmlhttp.send();


                   });
                   
                    $('#my_modal3').on('show.bs.modal', function(e) {
                  //  alert("abhay");
                    var ltype = $(e.relatedTarget).data('lead1-id');
                   //  alert(ltype);
                          //   $(e.currentTarget).find('label[id="lblleadid"]').text(ltype);

                           if (window.XMLHttpRequest)
                           {// code for IE7+, Firefox, Chrome, Opera, Safari
                               xmlhttp = new XMLHttpRequest();
                           }
                           else
                           {// code for IE6, IE5
                               xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                           }
                         //   alert("Hello Again "+processID);

                           xmlhttp.onreadystatechange = function ()
                           {
                               if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                               {
                                   document.getElementById("leadTimeline").innerHTML = xmlhttp.responseText;
                               }
                           }
                           document.getElementById("leadTimeline").style.display = "block";
                           xmlhttp.open("GET", "viewTimelines.php?q=" + ltype, true);
                           xmlhttp.send();


                   });
                   
             });
            
        