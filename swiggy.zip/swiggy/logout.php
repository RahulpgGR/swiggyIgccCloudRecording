<?php
session_start();
if(!isset($_SESSION)) {
      
    }
unset($_SESSION['UserID']);
 session_destroy();   
    session_unset(); 
header("location:../../login/index.html");

?>