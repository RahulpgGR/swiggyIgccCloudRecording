<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

session_start();

$r = $_GET['q'];

// $r = 'abhay@grassrootsbpo.com';

$txtOTP = rand(111111, 999999);
require_once '../PHPMailer-master/class.phpmailer.php';
require_once '../PHPMailer-master/class.smtp.php';
include_once 'grfilleremail.php';

// echo "OTP :: " . $r." ".$txtOTP;
// exit();



if ($r != '') {

   require_once '../db/db_connect.php';
$db = new db();
$con = $db->connect();
   echo  $sql = "Call SP_swiggy_GenerateOTP('" . $r . "'," . $txtOTP . ")";
    
//    echo $sql;
    
//    exit();
    
    
    $rows = $db->select($sql);
      
    if($db->error())
    {   
        echo "Error :: ".$db->error();
        exit();
    }
    else
    {
        echo "No Errors";
    
    // $result = mysql_query($sql); // $db);
    if ($rows === false) {
        echo "OTP Generation Unsuccessful. Contact Grassroots Administrator ";
        $_SESSION['error2'] = "OTP Generation Unsuccessful. Contact Grassroots Administrator ";
    } else {
        foreach ($rows as $row) {
			print_r($row);
            if ($row['eid'] != "0") {
             //    echo "sdsd";

                 sendMyOTP($row['eid'], $row['ename'], $txtOTP);
            }
        }
    }
    
}

 }

?>