<script type="text/javascript">  
                                                                                 
function TransferControl()
{
         window.location.href = ".";    
}

</script>

<?php
session_start();
function isMobileDevice(){
    $aMobileUA = array(
        '/iphone/i' => 'iPhone', 
        '/ipod/i' => 'iPod', 
        '/ipad/i' => 'iPad', 
        '/android/i' => 'Android', 
        '/blackberry/i' => 'BlackBerry', 
        '/webos/i' => 'Mobile'
    );

    //Return true if Mobile User Agent is detected
    foreach($aMobileUA as $sMobileKey => $sMobileOS){
        if(preg_match($sMobileKey, $_SERVER['HTTP_USER_AGENT'])){
            return true;
        }
    }
    //Otherwise return false..  
    return false;
}

/*
if(isMobileDevice())
    echo "Mobile Request";
else 
    echo "Desktop Request";

exit();
*/

$_SESSION['error2']= "";
 require_once '../db/db_connect.php';
$db = new db();
$con = $db->connect();
 $success = 0;
 
// username and password sent from form

echo $myusername=$_POST['txtUserName'];
echo $mypassword=$_POST['txtPassword'];
$myOTP = $_POST['txtOTP'];

// echo $myusername.' '.$mypassword.' '. $myOTP;

// To protect MySQL injection (more detail about MySQL injection)
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myOTP = stripslashes($myOTP);

// echo $myusername.' '.$mypassword.' '. $myOTP;

$myusername = mysqli_real_escape_string($con, $myusername);
$mypassword = mysqli_real_escape_string($con, $mypassword);
$myOTP = mysqli_real_escape_string($con, $myOTP);



// echo $myusername.' '.$mypassword.' '. $myOTP;

echo     $sql="call SP_Swiggy_GET_UserDetails('".$myusername."','".$mypassword. "','".$myOTP."')";

   
 //   echo $sql;
//    
 //   exit();
    
   // $rows = $db->select($sql); // $db); rahul
    $rows=['user'=>1];
    
    if($db->error())
    {   
        echo "Error :: ".$db->error();
        exit();
    }
    else
    {
        echo "No Errors";
      //  exit();
    
    if($rows === false) {
        
       // $error = $db->error();
        // Handle error - inform administrator, log to file, show error page, etc.
        
        CallLoginPage();
    }
    else
    {
        echo "Inside else";
        
        if(sizeof($rows) == 1)
        {
             echo "1 record macthes";
        
            //foreach($rows as $row) {
         
            $success = 1;

            // $_SESSION['UserID'] = $row['UserID'];
            
             $_SESSION['UserID'] = 1;

           // $_SESSION['EmailID'] = $row['EmailID'];
            
            // $_SESSION['EmployeeName'] = $row['EmployeeName'];

             $_SESSION['EmployeeName']='Rahul';

             // $_SESSION['Profile'] = $row['Profile'];
             
             $_SESSION['Profile'] = 'Rahul';       
            
           // header("location:../admin/index.php");
            
            //}
               

                          
           
        }
        else            
        {
     //       echo "records not matching";
            CallLoginPage($myusername);
        }

    }
 
    if($success == 1)
    {
            $profile_status='Rahul';



      //echo   $sql="call SP_swiggy_Insert_LoginSession('".$myusername."','S')";
       
         //echo $sql;
         
        //mysqli_next_result($con);
         
        //$result = $db->query($sql);
        
        //echo $db->error();
        
        // exit();
            // $_SESSION['EmailID'] = $row['EmailID'];
        // exit();        
     
		
			 $_SESSION['UserName']=$row['EmployeeName'];$_SESSION['status']=$row['Profile'];
		
    }

    }
    
function CallLoginPage($myusername){
    
   require_once '../db/db_connect.php';
$db = new db();
$con = $db->connect();
    $_SESSION['error2']= "&nbsp; Invalid UserName / Password / OTP / OTP Expired";
    
   echo  $sql="call SP_swiggy_Insert_LoginSession('".$myusername."','F')";
     
  //  $sql="insert into apar_User_LoginDetails(UserID, OTPVerified, Success)"
          //      . "  values(".$myusername.",1,0)";
        
     mysqli_next_result($con);
     
    $result = $db->query($sql); // $db);
            
            // $_SESSION['EmailID'] = $row['EmailID'];
      
    header("location:index.html");
    // exit();
    //echo "<script>TransferControl();</scipt>";
    
    
}



?>